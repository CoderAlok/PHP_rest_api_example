<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
        <ul>
            <li>
            <a href="https://www.creative-tim.com">
                Fresh on the go
            </a>
            </li>
        </ul>
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons text-danger">favorite</i> in India.
        </div>
        <!-- your footer here -->
    </div>
</footer>